export const environment = {
  production: true,
  api: 'https://rcerpapidev.worldofss.com/api/v1/'
};
