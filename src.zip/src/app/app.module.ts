import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NZ_I18N } from 'ng-zorro-antd/i18n';
import { en_US } from 'ng-zorro-antd/i18n';
import { registerLocaleData } from '@angular/common';
import en from '@angular/common/locales/en';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

// custom components
import { GridComponent } from './grid/grid.component';

// ant design module
import { AntModue } from 'src/modules/ant.module';

// services
import { ItemsService } from 'src/services/items/items.service';
import { GenericGridComponent } from './generic-grid/generic-grid.component';

// pipes
import { RenderPipe } from 'src/pipes/render.pipe';

registerLocaleData(en);

@NgModule({
  declarations: [
    AppComponent,
    GridComponent,
    GenericGridComponent,
    RenderPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    AntModue
  ],
  providers: [
    { provide: NZ_I18N, useValue: en_US },    
    ItemsService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
