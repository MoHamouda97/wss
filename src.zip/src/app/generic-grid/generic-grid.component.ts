import { Component, Input, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-generic-grid',
  templateUrl: './generic-grid.component.html',
  styleUrls: ['./generic-grid.component.css']
})
export class GenericGridComponent implements OnInit {
  gridForm!: FormGroup;
  @Input('tblInfo') tblInfo: any; // this prop will give the table the info that will be used to render it dynamiclly

  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    this.gridForm = this.fb.group({
      controls: this.fb.array([])
    });
    this.addControls()
  }

  //#region // create dynamic form using FormArray techniq

  public get getControls() : FormArray { // to return controls from main FormGroup
    return this.gridForm.get('controls') as FormArray
  }

  addControls() { // to push new controls to our FormArray
    // use ES6 spread operator to add control name that received from tblInfo prop 
    // to our FormArray at once time 
    this.getControls.push(this.fb.group({...this.tblInfo["controlsName"]})) 
  }

  removeControls(i: number) { // remove controls from form array
    this.getControls.removeAt(i);
  }

  //#endregion

}
