import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'ng-task';
  // data taht each dynamic table will need
  tblInfo: any = {
    tbltHeader: [
      'Test 1',
      'Test 2',
      'Test 3',
      'خيارات',
    ],
    tblControls: [      
      {control1: 'text', control2: 'email', control3: 'number', remove: 'remove'}
    ],
    controlsName: {control1: '', control2: '', control3: ''}
  }  
}
